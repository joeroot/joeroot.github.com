require('./object');
require('./variable');
require('./class');
require('./method');

require('./core/boolean');
require('./core/number');
require('./core/string');
require('./core/list');
require('./core/system');
