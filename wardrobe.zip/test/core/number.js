/*
 * Methods: add, multiply, subtract, divide, equal, greaterThan, lessThan, negative 
 */
