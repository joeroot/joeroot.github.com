var Wardrobe = require('../src/wardrobe');
var assert = require('assert');

describe('String', function(){
  describe('#toString', function(){
    it('should return a String object', function(){
    });
  });
});
