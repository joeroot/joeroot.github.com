function logToConsole(x) {
  print(x);
}
